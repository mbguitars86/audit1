# Life Priorities App MVP

Open `index.html` in a modern browser. No server is required.

Includes 50 questions across 10 categories, importance/satisfaction/urgency scoring, priority-gap ranking, action planning, local persistence, and print/save-to-PDF.
